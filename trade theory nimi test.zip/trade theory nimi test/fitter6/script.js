const questions = [
    { qNum: 251, question: "Which type of jig do not have base plate? किस प्रकार के जिग मे बेस प्लेट नहीं होता है?", options: ["Table jig टेबल जिग", "Plate jig प्लेट जिग", "Template jig टेम्पलेट जिग", "Sandwich jig सैंडविच जिग"], answer: 2, image: "" },
    { qNum: 252, question: "What is the name of jig? इस जिग का नाम क्या है?", options: ["Leaf jig लीफ जिग", "Solid jig सॉलिड जिग", "Table jig टेबल जिग", "Angle plate jig एंगल प्लेट जिग"], answer: 3, image: "images/q252.png" },
    { qNum: 253, question: "What is the name of jig? इस जिग का नाम क्या है?", options: ["Box jig बॉक्स जिग", "Post jig पोस्ट जिग", "Turn over jig टर्न ओवर जिग", "Sandwich jig सैंडविच जिग"], answer: 2, image: "" },
    { qNum: 254, question: "What is里有name of clamp? इस क्लैंप का नाम क्या है?", options: ["Strap clamp स्ट्रैप क्लैंप", "Cam clamp कैम क्लैंप", "Latch clamp लैच क्लैंप", "Screw clamp स्क्रू क्लैंप"], answer: 1, image: "" },
    { qNum: 255, question: "What is the name of fixture? इस फिक्सचर का नाम क्या है?", options: ["Plate fixture प्लेट फिक्सचर", "Angle plate fixture एंगल प्लेट फिक्सचर", "Indexing plate fixture इंडेक्सिंग प्लेट फिक्सचर", "Modified angle plate fixture मॉडिफाइड एंगल प्लेट फिक्सचर"], answer: 3, image: "" },
    { qNum: 256, question: "Which type of bush is used in jig to perform more than one operation in same location? एक ही स्थान पर एक से अधिक ऑपरेशन करने के लिए जिग मे किस प्रकार की बुश का उपयोग किया जाता है?", options: ["Slip bush स्लिप बुश", "Plain bush प्लेन बुश", "Fixed bush फिक्स्ड बुश", "Liner bush लाइनर बुश"], answer: 0, image: "" },
    { qNum: 257, question: "What is the purpose of grooves provided in the 'V' blocks? 'V' ब्लॉक में दिए गए ग्रूव्स का उद्देश्य क्या है?", options: ["Reduce the weight वजन कम करना", "Support the work piece कार्य खण्ड को सपोर्ट करना", "Accommodate the clamp क्लैंप को समायोजित करना", "Allow thermal expansion थर्मल विस्तार की अनुमति देना"], answer: 2, image: "" },
    { qNum: 258, question: "Why the balancing weight is provided in the turning fixture? टर्निंग फिक्सचर में बैलेंसिंग वेट क्यों प्रदान किया जाता है?", options: ["To guide tool टूल को गाइड करने के लिए", "To balance the tool टूल को बैलेंस करने के लिए", "To balance worktable वर्क टेबल को बैलेंस करने के लिए", "To balance irregular workpiece अनियमित वर्कपीस को संतुलित करने के लिए"], answer: 3, image: "" },
    { qNum: 259, question: "Which type of fixture is used for machining on evenly spaced surfaces? समान रूप से सधानिक सतहों पर मशीनिंग के लिए किस प्रकार की फिक्सचर का उपयोग किया जाता है?", options: ["Plate fixture प्लेट फिक्सचर", "Vice jaw fixture वाइस जॉ फिक्सचर", "Indexing fixture इंडेक्सिंग फिक्सचर", "Angle plate fixture एंगल प्लेट फिक्सचर"], answer: 2, image: "" },
    { qNum: 260, question: "What is the name of jig? इस जिग का नाम क्या है?", options: ["Post jig पोस्ट जिग", "Solid jig सॉलिड जिग", "Channel jig चैनल जिग", "Trunnion jig ट्रनियन जिग"], answer: 2, image: "" },
    { qNum: 261, question: "Which is the important factor to determine the construction of fixture? फिक्सचर के निर्माण का निर्धारण करने के लिए कौन सा महत्वपूर्ण कारक है?", options: ["Machining method मशीनिंग की विधि", "Location and clamping लोकेटिंग और क्लैंपिंग", "Tool guiding and frame टूल गाइडिंग और फ्रेम", "Size of work piece and tool कार्य खण्ड और टूल का साइज"], answer: 0, image: "" },
    { qNum: 262, question: "What is the purpose of setting blocks used in the fixture? फिक्सचर में उपयोग किए जाने वाले सेटिंग ब्लॉक का उद्देश्य क्या है?", options: ["Position the balancing weight संतुलन वजन की स्थिति", "Position the clamp and locators क्लैंप और लोकेटर की स्थिति", "Position the fixture on machine table मशीन की मेज पर फिक्सचर की स्थिति", "Position the fixture and work related to cutter कटर से संबंधित फिक्सचर और काम की स्थिति"], answer: 3, image: "" },
    { qNum: 263, question: "Which type of jig is used for awkwardly shaped work piece to drill at different angles? विभिन्न कोणों में अजीब आकार के काम को ड्रिल करने के लिए किस प्रकार का जिग उपयोग किया जाता है?", options: ["Post jig पोस्ट जिग", "Solid jig सॉलिड जिग", "Indexing jig इंडेक्सिंग जिग", "Trunnion jig ट्रनियन जिग"], answer: 3, image: "" },
    { qNum: 264, question: "Which device holds, supports, locates and also guide the cutting tool for operation? कौन सा उपकरण ऑपरेशन के लिए कटिंग टूल को पकड़ता, सपोर्ट करता, लोकेट और साथ-साथ गाइड भी करता है?", options: ["Jig जिग", "Fixture फिक्सचर", "Chuck चक", "Machine vice मशीन वाइस"], answer: 0, image: "" },
    { qNum: 265, question: "What is the name of clamp used in jig? जिग में प्रयुक्त क्लैंप का नाम क्या है?", options: ["Tooth clamp टूथ क्लैंप", "Latch clamp लैच क्लैंप", "Toggle clamp टॉगल क्लैंप", "Wedge clamp वेज क्लैंप"], answer: 2, image: "" },
    { qNum: 266, question: "Why two or four hold down slots are provided in the base plate of milling fixture? मिलिंग फिक्सचर के बेस प्लेट में दो या चार होल्ड डाउन स्लॉट क्यों प्रदान किए जाते हैं?", options: ["For rigid clamping कठोर क्लैंपिंग के लिए", "For guiding the tool टूल को गाइड करने के लिए", "For locating workpiece वर्कपीस को लोकेट करने के लिए", "For adjusting the job setting जॉब सेटिंग को समायोजित करने के लिए"], answer: 0, image: "" },
    { qNum: 267, question: "What is the advantages of mass production? बड़े पैमाने पर उत्पादन के क्या फायदे हैं?", options: ["Initial expenditure is low प्रारंभिक व्यय कम है", "Jigs and fixture are not needed जिग्स और फिक्सचर की आवश्यकता नहीं है", "Cost and time reduced for manufacturing मैन्युफैक्चरिंग के लिए लागत और समय कम हो गया", "Special purpose machines are not necessary विशेष प्रयोजन मशीन आवश्यक नहीं है"], answer: 2, image: "" },
    { qNum: 268, question: "What is the name of jig? इस जिग का नाम क्या है?", options: ["Box jig बॉक्स जिग", "Drill jig ड्रिल जिग", "Post jig पोस्ट जिग", "Leaf jig लीफ जिग"], answer: 0, image: "" },
    { qNum: 269, question: "What is the method of lubrication? इस स्नेहन की विधि क्या है?", options: ["Force feed फोर्स फीड", "Gravity feed ग्रैविटी फीड", "Splash feed स्प्लैश फीड", "Line feed लाइन फीड"], answer: 0, image: "" },
    { qNum: 270, question: "Which bush is used to provide a hardened hole for renewable bushes? रिन्यूएबल बुशेस के लिए कठोर छेद प्रदान करने के लिए किस बुश का उपयोग किया जाता है?", options: ["Slip bush स्लिप बुश", "Plain bush प्लेन बुश", "Fixed bush फिक्स्ड बुश", "Liner bush लाइनर बुश"], answer: 3, image: "" },
    { qNum: 271, question: "What is the name of clamp? इस क्लैंप का नाम क्या है?", options: ["Cam clamp कैम क्लैंप", "Screw clamp स्क्रू क्लैंप", "Wedge clamp वेज क्लैंप", "Toggle clamp टॉगल क्लैंप"], answer: 1, image: "" },
    { qNum: 272, question: "Which device is used to hold, locate and not guide the cutting tool during machining operation? मशीनिंग ऑपरेशन के दौरान कटिंग टूल को स्थिर पकड़ना, लोकेट करना और गाइड नहीं करने के लिए किस उपकरण का उपयोग किया जाता है?", options: ["Jig जिग", "Fixture फिक्सचर", "C clamp C क्लैंप", "Machine vice मशीन वाइस"], answer: 1, image: "" },
    { qNum: 273, question: "Which type of fixture provides an easy method of holding parts for machining? किस प्रकार का फिक्सचर मशीनिंग के लिए भागों को पकड़ने के लिए एक आसान तरीका प्रदान करता है?", options: ["Turning fixture टर्निंग फिक्सचर", "Vice fixture वाइस फिक्सचर", "Milling fixture मिलिंग फिक्सचर", "Grinding fixture ग्राइंडिंग फिक्सचर"], answer: 1, image: "" },
    { qNum: 274, question: "Which part restricts incorrect loading of component in jig? कौन सा भाग जिग में घटक की गलत लोडिंग को प्रतिबंधित करता है?", options: ["Clamp क्लैंप", "Guide plate गाइड प्लेट", "Locating pin लोकेटिंग पिन", "Press fit bush प्रेस फिट बुश"], answer: 2, image: "" },
    { qNum: 275, question: "What is the type of jig? इस जिग का प्रकार क्या है?", options: ["Post jig पोस्ट जिग", "Plate jig प्लेट जिग", "Indexing jig इंडेक्सिंग जिग", "Angle plate jig एंगल प्लेट जिग"], answer: 2, image: "" },
    { qNum: 276, question: "Why tenons are provided at the bottom of base plate of milling fixture? मिलिंग फिक्सचर के बेस प्लेट के निचले भाग में टेनन क्यों प्रदान किए जाते हैं?", options: ["For guiding the tool टूल को गाइड करने के लिए", "For clamping purpose क्लैंपिंग उद्देश्य के लिए", "For balancing workpiece वर्कपीस को संतुलित करने के लिए", "For proper location of fixture फिक्सचर को सही तरह से लोकेट करने के लिए"], answer: 3, image: "" },
    { qNum: 277, question: "What is the purpose of drill bushes provided in the drill jig? ड्रिल जिग में ड्रिल बुशेस का उद्देश्य क्या है?", options: ["To support base plate बेस प्लेट को सपोर्ट करने के लिए", "To support drill plate ड्रिल प्लेट को सपोर्ट करने के लिए", "To locate and guide cutting tool कटिंग टूल को गाइड करना और लोकेट करना", "To restrict the movement of job जॉब के मूवमेंट को रोकने के लिए"], answer: 2, image: "" },
    { qNum: 278, question: "What is the name of fixture? इस फिक्सचर का नाम क्या है?", options: ["Vice fixture वाइस फिक्सचर", "Solid fixture सॉलिड फिक्सचर", "Plate fixture प्लेट फिक्सचर", "Indexing fixture इंडेक्सिंग फिक्सचर"], answer: 3, image: "" },
    { qNum: 279, question: "What is the colour of the aluminium metal? एल्यूमिनियम धातु का रंग क्या है?", options: ["Yellow पीला", "Reddish लाल सा", "Whitish grey वाइटिश ग्रे", "Silvery white सिल्वरी वाइट"], answer: 2, image: "" },
    { qNum: 280, question: "Which ore produces lead metal? किस अयस्क से सीसा धातु उत्पन्न होती है?", options: ["Pyrites पाइराइट्स", "Bauxite बॉक्साइट", "Malachite मैलाकाइट", "Galena गैलेना"], answer: 3, image: "" },
    { qNum: 281, question: "What is the name of metal alloy of lead, tin, copper and antimony? सीसा, टिन, तांबा और एंटीमनी के मिश्र धातु का नाम क्या है?", options: ["Bronze कांस्य", "Gilding metal गिल्डिंग मेटल", "Babbitt metal बैबिट मेटल", "Leaded bronze लेडेड ब्रॉन्ज"], answer: 2, image: "" },
    { qNum: 282, question: "What is the ratio of copper and zinc in 'Muntz metal'? 'मुंट्ज़ मेटल' में तांबा और जस्ता का अनुपात क्या है?", options: ["63:37", "60:40", "57:43", "70:30"], answer: 1, image: "" },
    { qNum: 283, question: "Which metal is extracted from bauxite ore? बॉक्साइट अयस्क से किस धातु को निकाला जाता है?", options: ["Zinc जस्ता", "Brass पीतल", "Copper तांबा", "Aluminium एल्यूमिनियम"], answer: 3, image: "" },
    { qNum: 284, question: "Which metal is used in the preparation of paint? पेंट बनाने में किस धातु का उपयोग किया जाता है?", options: ["Zinc जस्ता", "Lead लेड", "Brass पीतल", "Aluminium एल्यूमिनियम"], answer: 1, image: "" },
    { qNum: 285, question: "Which type of belt drive, the driven shaft will rotate in opposite direction to driver shaft? किस प्रकार का बेल्ट ड्राइव, संचालित शाफ्ट ड्राइवर शाफ्ट के विपरीत दिशा में घूमेगा?", options: ["Stepped drive स्टेप्ड ड्राइव", "Open belt drive ओपन बेल्ट ड्राइव", "Cross belt drive क्रॉस बेल्ट ड्राइव", "Right angled belt drive राइट एंगल्ड बेल्ट ड्राइव"], answer: 2, image: "" },
    { qNum: 286, question: "What is the name of belt fastener? बेल्ट फास्टनर का नाम क्या है?", options: ["Wire type वायर टाइप", "Lagrelle type लगरेल टाइप", "Alligator type एलीगेटर टाइप", "Crescent plate type क्रेसेंट प्लेट टाइप"], answer: 2, image: "" },
    { qNum: 287, question: "What is the type of gear? गियर का प्रकार क्या है?", options: ["Spur gear स्पर गियर", "Mitre gear माइटर गियर", "Hypoid gear हाइपॉइड गियर", "Herring bone gear हेरिंग बोन गियर"], answer: 1, image: "" },
    { qNum: 288, question: "What is the name of part marked X in the belt drive? बेल्ट ड्राइव में X के रूप से चिह्नित भाग का नाम क्या है?", options: ["Step pulley स्टेप पुली", "Driver pulley ड्राइवर पुली", "Driven pulley ड्रिवेन पुली", "Jockey pulley जॉकी पुली"], answer: 3, image: "" },
    { qNum: 289, question: "Which type of gear drive changes rotary movement to linear movement? किस प्रकार का गियर ड्राइव रोटरी चाल को रैखिक चाल में बदलता है?", options: ["Hypoid हाइपॉइड", "Herring bone हेरिंग बोन", "Rack and pinion रैक और पिनियन", "Helical gear हेलिकल गियर"], answer: 2, image: "" },
    { qNum: 290, question: "What is the name of the part marked 'X' in gear? गियर में 'X' के रूप से चिह्नित भाग का नाम क्या है?", options: ["Pitch line पिच लाइन", "Dedendum डेडेंडम", "Addendum एडेंडम", "Face width फेस की चौड़ाई"], answer: 3, image: "" },
    { qNum: 291, question: "Which type of belt is used if the distance between the shafts are too short? यदि शाफ्ट के बीच की दूरी बहुत कम है, तो किस प्रकार की बेल्ट का उपयोग किया जाता है?", options: ["V belt वी बेल्ट", "Flat belt फ्लैट बेल्ट", "Link belt लिंक बेल्ट", "Ribbed belt रिब्ड बेल्ट"], answer: 0, image: "" },
    { qNum: 292, question: "Why the small steel wedge is tapped under the machine in lifting operation? छोटे स्टील वेज को लिफ्टिंग ऑपरेशन में मशीन के नीचे क्यों रखा जाता है?", options: ["To prevent vibration कंपन को रोकने के लिए", "To reduce the weight वजन कम करने के लिए", "To accept the crowbar क्रो बार स्वीकार करने के लिए", "To balance the machine मशीन को संतुलित करने के लिए"], answer: 2, image: "" },
    { qNum: 293, question: "How to adjust the tension of belt between two fixed pulleys? दो फिक्स्ड पुली के बीच बेल्ट के तनाव को कैसे समायोजित करें?", options: ["By sliding the pulley पुली को स्लाइड करके", "By fixing idler pulley आइडलर पुली को फिक्स करके", "By adjusting the length of belt बेल्ट की लंबाई को एडजस्ट करके", "By adjusting the screw of pulley पुली के स्क्रू को एडजस्ट करके"], answer: 1, image: "" },
    { qNum: 294, question: "Why vertical belt drive is avoided in power transmission? पावर ट्रांसमिशन में वर्टिकल बेल्ट ड्राइव का इस्तेमाल क्यों नहीं करना चाहिए?", options: ["Because of small wrapping of belt बेल्ट के छोटे लपेटने की वजह से", "Because of excessive contact अत्यधिक संपर्क के कारण", "Because of gravitational pull and slippage गुरुत्वाकर्षण खिंचाव और फिसलन के कारण", "Because of increase in surface speed of pulleys पुली की सतह की गति में वृद्धि के कारण"], answer: 2, image: "" },
    { qNum: 295, question: "What is the name of the coupling? कपलिंग का नाम क्या है?", options: ["Slip coupling स्लिप कपलिंग", "Plate coupling प्लेट कपलिंग", "Clamp coupling क्लैंप कपलिंग", "Universal coupling यूनिवर्सल कपलिंग"], answer: 3, image: "" },
    { qNum: 296, question: "Why the face of pulley is 'Crowned' in power transmission? पावर ट्रांसमिशन में पुली का फेस 'क्राउन' क्यों होता है?", options: ["Increase the tension तनाव बढ़ाने के लिए", "Decrease the tension तनाव कम करने के लिए", "Keep the belt centralised बेल्ट को केंद्रीकृत रखने के लिए", "Allow the pulley free rotation पुली को स्वतंत्र रूप से घूमने के लिए"], answer: 2, image: "" },
    { qNum: 297, question: "Which graphical representation of the activities performed during manufacturing? विनिर्माण के दौरान की गई गतिविधियों का कौन सा आलेखी प्रतिनिधित्व है?", options: ["Job card जॉब कार्ड", "Process chart प्रक्रिया चार्ट", "Batch record form बैच रिकॉर्ड फॉर्म", "Batch processing form बैच प्रोसेसिंग फॉर्म"], answer: 1, image: "" },
    { qNum: 298, question: "What is the name of the part marked X in fast and loose pulley assembly? फास्ट और लूज़ पुली असेंबली में X के रूप में चिह्नित भाग का नाम क्या है?", options: ["Fast pulley फास्ट पुली", "Loose pulley लूज़ पुली", "Crown pulley क्राउन पुली", "Flat drive pulley फ्लैट ड्राइव पुली"], answer: 2, image: "" },
    { qNum: 299, question: "Which coupling is used in the place for slight relative movement is required? अल्प रिलेटिव मूवमेंट के लिए किस कपलिंग का उपयोग किया जाता है?", options: ["Chain coupling चेन कपलिंग", "Flange coupling फ्लैंज कपलिंग", "Flexible coupling फ्लेक्सिबल कपलिंग", "Muff coupling मफ कपलिंग"], answer: 2, image: "" },
    { qNum: 300, question: "Which is the imaginary circle on two mating gears? दो मैटिंग गियर पर काल्पनिक सर्कल कौन सा है?", options: ["Root circle रूट सर्कल", "Pitch circle पिच सर्कल", "Base circle बेस सर्कल", "Addendum circle एडेंडम सर्कल"], answer: 1, image: "" }
];

let timeLeft = 1500; // 25 minutes (1500 seconds) for 50 questions
let score = 0;

function displayQuestions() {
    const container = document.getElementById('question-container');
    questions.forEach((q) => {
        let html = `
            <div class="question" id="question-${q.qNum}">
                <h3>Question ${q.qNum}: ${q.question}</h3>
                ${q.image ? `<img src="${q.image}" alt="Question ${q.qNum} diagram">` : ''}
                <div class="options" id="options-${q.qNum}">`;
        
        q.options.forEach((option, i) => {
            html += `
                <label class="option-label">
                    <input type="radio" name="q${q.qNum}" value="${i}">
                    <span class="option-text" id="option-${q.qNum}-${i}">${option}</span>
                </label>`;
        });
        
        html += `
                </div>
                <div class="status" id="status-${q.qNum}"></div>
            </div>`;
        container.innerHTML += html;
    });
}

function startTimer() {
    const timer = document.getElementById('timer');
    const interval = setInterval(() => {
        timeLeft--;
        timer.textContent = Math.floor(timeLeft / 60) + ':' + (timeLeft % 60).toString().padStart(2, '0');
        if (timeLeft <= 0) {
            clearInterval(interval);
            submitQuiz();
        }
    }, 1000);
}

function goBack() {
    window.location.href = 'http://127.0.0.1:16048/main/0/storage/emulated/0/Alarms/trade%20theory%20nimi%20test/index.html'; // Assumes a topics.html exists locally
}

function submitQuiz() {
    let correct = 0;
    let wrong = 0;
    let notAttempted = 0;
    const total = questions.length;

    questions.forEach((q) => {
        const selected = document.querySelector(`input[name="q${q.qNum}"]:checked`);
        const userAnswer = selected ? parseInt(selected.value) : -1;
        const statusDiv = document.getElementById(`status-${q.qNum}`);
        const correctOption = document.getElementById(`option-${q.qNum}-${q.answer}`);

        correctOption.classList.add('correct-answer');

        if (userAnswer === -1) {
            statusDiv.textContent = "Not Attempted";
            statusDiv.classList.add('not-attempted');
            notAttempted++;
        } else if (userAnswer === q.answer) {
            correct++;
        } else {
            const wrongOption = document.getElementById(`option-${q.qNum}-${userAnswer}`);
            wrongOption.classList.add('incorrect-answer');
            wrong++;
        }

        document.querySelectorAll(`input[name="q${q.qNum}"]`).forEach(radio => radio.disabled = true);
    });

    const resultDiv = document.getElementById('result');
    resultDiv.classList.remove('hidden');
    resultDiv.innerHTML = `
        <div class="result-box">
            <h2>Result</h2>
            <p>Correct Answers: ${correct}</p>
            <p>Wrong Answers: ${wrong}</p>
            <p>Not Attempted: ${notAttempted}</p>
            <p>Percentage Correct: ${((correct / total) * 100).toFixed(2)}%</p>
            <p>Percentage Wrong: ${((wrong / total) * 100).toFixed(2)}%</p>
            <p>Percentage Not Attempted: ${((notAttempted / total) * 100).toFixed(2)}%</p>
        </div>`;
    document.getElementById('submit-btn').disabled = true;
}

window.onload = () => {
    displayQuestions();
    startTimer();
};