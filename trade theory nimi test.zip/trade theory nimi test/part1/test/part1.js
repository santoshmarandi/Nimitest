console.log("Script loaded successfully");
const questions = [
    { qNum: 1, question: "Which special file is used for narrow work? संकीर्ण कार्य के लिए किस विशेष फाइल का उपयोग किया जाता है?", options: ["Pillar file पिलर फाइल", "Square file स्क्वायर फाइल", "Dread naught file ड्रेडनॉट फाइल", "Swiss pattern file स्विस पैटर्न फाइल"], answer: 0, image: "images/question1.png" },
    { qNum: 2, question: "Why slots are provided in the slotted castle nuts? स्लॉटेड कैसल नट्स में स्लॉट्स क्यों प्रदान किए जाते हैं?", options: ["To fix split pins स्प्लिट पिन्स को ठीक करने के लिए", "For good appearance अच्छी दिखावट के लिए", "Reduce the weight of nut नट का वजन कम करने के लिए", "For easy removal and fitment आसानी से हटाने और फिट करने के लिए"], answer: 0, image: "images/question2.png" },
    { qNum: 3, question: "What is the name of limit gauge? इस लिमिट गेज का नाम क्या है?", options: ["Plain ring gauge प्लेन रिंग गेज", "Taper plug gauge टेपर प्लग गेज", "Progressive plug gauge प्रोग्रेसिव प्लग गेज", "Double ended plug gauge डबल एंडेड प्लग गेज"], answer: 2, image: "images/question3.png" },
    { qNum: 4, question: "What is the name of gauge? इस गेज का नाम क्या है?", options: ["Ring gauge रिंग गेज", "Plug gauge प्लग गेज", "Taper ring gauge टेपर रिंग गेज", "Taper plug gauge टेपर प्लग गेज"], answer: 0, image: "images/question4.png" },
    { qNum: 5, question: "Which gauge is used to check the gap between the mating parts? मिलने वाले भागों के बीच की खाई जांचने के लिए कौन सा गेज उपयोग किया जाता है?", options: ["Slip gauge स्लिप गेज", "Plug gauge प्लग गेज", "Feeler gauge फीलर गेज", "Radius gauge रेडियस गेज"], answer: 2, image: "images/question5.png" },
    { qNum: 6, question: "Which material is used to clean the slip gauge? स्लिप गेज को साफ करने के लिए कौन सी सामग्री उपयोग की जाती है?", options: ["Wax मोम", "Kerosene मिट्टी तेल", "Soluble oil घुलनशील तेल", "Carbon tetra chloride कार्बन टेट्राक्लोराइड"], answer: 3, image: "images/question6.png" },
    { qNum: 7, question: "Which material is to wash off the lapping plate after charging? चार्जिंग के बाद लैपिंग प्लेट को धोने के लिए कौन सी सामग्री उपयोग की जाती है?", options: ["Oil तेल", "Kerosene मिट्टी तेल", "Coolant oil कूलेंट तेल", "Petroleum jelly पेट्रोलियम जेली"], answer: 1, image: "images/question7.png" },
    { qNum: 8, question: "Which material is used to protect slip gauge from rust? स्लिप गेज को जंग से बचाने के लिए कौन सी सामग्री उपयोग की जाती है?", options: ["Oil तेल", "Wax मोम", "Kerosene मिट्टी तेल", "Petroleum jelly पेट्रोलियम जेली"], answer: 3, image: "images/question8.png" },
    { qNum: 9, question: "What is the procedure to built up the slip gauge for particular dimension? विशेष आयाम के लिए स्लिप गेज का निर्माण करने की प्रक्रिया क्या है?", options: ["Start wringing with the largest slip gauges सबसे बड़ी स्लिप गेज के साथ रिंगिंग शुरू करें", "Maximum number of block अधिकतम ब्लॉकों की संख्या", "Built with grade 0 accuracy ग्रेड 0 सटीकता के साथ निर्मित", "Start wringing with the small slip gauge छोटी स्लिप गेज के साथ रिंगिंग शुरू करें"], answer: 0, image: "images/question9.png" },
    { qNum: 10, question: "What is the name of the gauge? इस गेज का नाम क्या है?", options: ["Plain snap gauge प्लेन स्नैप गेज", "Thread snap gauge थ्रेड स्नैप गेज", "Thread pitch gauge थ्रेड पिच गेज", "Adjustable snap gauge एडजस्टेबल स्नैप गेज"], answer: 3, image: "images/question10.png" },
    { qNum: 11, question: "Which finishing process have a high degree of dimensional accuracy? आयामी सटीकता की उच्च डिग्री के साथ कौन सी फिनिशिंग प्रक्रिया है?", options: ["Filing फाइलिंग", "Turning टर्निंग", "Grinding ग्राइंडिंग", "Lapping लैपिंग"], answer: 3, image: "images/question11.png" },
    { qNum: 12, question: "Which is the abrasive used for lapping soft steel and non-ferrous metals? नरम स्टील और गैर-लौह धातुओं के लिए लैपिंग में उपयोग किया जाने वाला अपघर्षक कौन सा है?", options: ["Silicon carbide सिलिकॉन कार्बाइड", "Diamond डायमंड", "Boron carbide बोरॉन कार्बाइड", "Fused alumina फ्यूज्ड एल्यूमिना"], answer: 3, image: "images/question12.png" },
    { qNum: 13, question: "Why grooves are provided on the surface of the lapping plate? लैपिंग प्लेट की सतह पर खांचे क्यों प्रदान किए जाते हैं?", options: ["To allow expansion विस्तार की अनुमति देने के लिए", "To provide clearance क्लियरेंस प्रदान करने के लिए", "To retain the abrasive अपघर्षक को बनाए रखने के लिए", "To permit minor adjustment मामूली समायोजन की अनुमति देने के लिए"], answer: 2, image: "images/question13.png" },
    { qNum: 14, question: "What is the method of surface hardening? सतह कठोरन करने की विधि क्या है?", options: ["Nitriding नाइट्राइडिंग", "Pack - carburising पैक - कार्बराइजिंग", "Flame hardening फ्लेम हार्डनिंग", "Induction hardening इंडक्शन हार्डनिंग"], answer: 1, image: "images/question14.png" },
    { qNum: 15, question: "What is the method of surface hardening? सतह कठोरन करने की विधि क्या है?", options: ["Nitriding नाइट्राइडिंग", "Case hardening केस हार्डनिंग", "Flame hardening फ्लेम हार्डनिंग", "Induction hardening इंडक्शन हार्डनिंग"], answer: 2, image: "images/question15.png" },
    { qNum: 16, question: "What is the name of the heat treatment process for reheating the hardened steel to a temperature below 400°C followed by cooling? 400°C से नीचे के तापमान पर कठोर स्टील को पुनः गरम करके फिर ठंडा करने के लिए हीट ट्रीटमेंट प्रक्रिया का नाम क्या है?", options: ["Annealing ऐनीलिंग", "Hardening हार्डनिंग", "Tempering टेंपरिंग", "Normalising नॉर्मलाइजिंग"], answer: 2, image: "images/question16.png" },
    { qNum: 17, question: "Why the tempering process carried out in steel? स्टील में टेंपरिंग प्रक्रिया क्यों की जाती है?", options: ["To add cutting ability काटने की क्षमता जोड़ने के लिए", "To relive strain and stress तनाव और दबाव को दूर करने के लिए", "To refine the grain structure अनाज संरचना को परिष्कृत करने के लिए", "To regulate the hardness and toughness कठोरता और मजबूती को नियंत्रित करने के लिए"], answer: 3, image: "images/question17.png" },
    { qNum: 18, question: "What is the purpose of annealing in steel? स्टील में ऐनीलिंग का उद्देश्य क्या है?", options: ["To add cutting ability काटने की क्षमता जोड़ने के लिए", "To increase wear resistance पहनने के प्रतिरोध को बढ़ाने के लिए", "To relieve the internal stress आंतरिक तनाव को दूर करने के लिए", "To refine the grain structure of the steel स्टील की अनाज संरचना को परिष्कृत करने के लिए"], answer: 2, image: "images/question18.png" },
    { qNum: 19, question: "What is the name of the key? इस की का नाम क्या है?", options: ["Sunk key सनक की", "Feather key फेदर की", "Flat saddle key फ्लैट सैडल की", "Hollow saddle key हॉलो सैडल की"], answer: 1, image: "images/question19.png" },
    { qNum: 20, question: "What is the purpose of key? की का उद्देश्य क्या है?", options: ["To transmit torque टॉर्क को ट्रांसमिट करने के लिए", "Assembly purpose असेंबली के उद्देश्य के लिए", "Lock the assembly part असेंबली भाग को लॉक करना", "Permit clearance between mating part मिलने वाले भाग के बीच क्लियरेंस प्रदान करना"], answer: 0, image: "images/question20.png" },
    { qNum: 21, question: "What is the ratio of key way taper? कीवे टेपर का अनुपात क्या है?", options: ["01:19:00", "01:20:00", "01:50:00", "1:100"], answer: 3, image: "images/question21.png" },
    { qNum: 22, question: "What is the name of key? इस की का नाम क्या है?", options: ["Taper sunk key टेपर सनक की", "Flat saddle key फ्लैट सैडल की", "Parallel sunk key पैरलल सनक की", "Hallow saddle key हॉलो सैडल की"], answer: 0, image: "images/question22.png" },
    { qNum: 23, question: "Which type of metal screws useful for self tapping on hard or brittle materials? कठोर या भंगुर सामग्रियों पर सेल्फ-टैपिंग के लिए किस प्रकार के मेटल स्क्रू उपयोगी हैं?", options: ["Self piercing सेल्फ पियर्सिंग", "Thread cutting थ्रेड कटिंग", "Thread forming थ्रेड फॉर्मिंग", "Hammer driven screw हथौड़ा ड्रिवन स्क्रू"], answer: 1, image: "images/question23.png" },
    { qNum: 24, question: "What is the advantage of wing nut? विंग नट का लाभ क्या है?", options: ["In coach building work कोच निर्माण कार्य में", "Heavy duty assembly work भारी ड्यूटी असेंबली कार्य में", "Loosen and tighten without wrench बिना रेंच के ढीला और कसना", "Provide decorative appearance सजावटी उपस्थिति प्रदान करना"], answer: 2, image: "images/question24.png" },
    { qNum: 25, question: "What is the name of gauge? इस गेज का नाम क्या है?", options: ["Pitch gauge पिच गेज", "Angle gauge एंगल गेज", "Feeler gauge फीलर गेज", "Radius gauge रेडियस गेज"], answer: 3, image: "images/question25.png" },
    { qNum: 26, question: "Which gauge is used to check the accuracy of an external thread? बाहरी थ्रेड की सटीकता जांचने के लिए कौन सा गेज उपयोग किया जाता है?", options: ["Snap gauge स्नैप गेज", "Thread ring gauge थ्रेड रिंग गेज", "Thread plug gauge थ्रेड प्लग गेज", "Centre gauge सेंटर गेज"], answer: 1, image: "images/question26.png" },
    { qNum: 27, question: "What is the instrument used in measuring external diameter? बाहरी व्यास को मापने में उपयोग किया जाने वाला उपकरण क्या है?", options: ["Vernier caliper वर्नियर कैलिपर", "Outside caliper आउटसाइड कैलिपर", "Parallel leg caliper पैरलल लेग कैलिपर", "Pair of special jaws by using slip gauge स्लिप गेज का उपयोग करके विशेष जब्स की जोड़ी"], answer: 3, image: "images/question27.png" },
    { qNum: 28, question: "Find out the height of slip gauge 'a'? (sin 25° = 0.4226) स्लिप गेज 'a' की ऊंचाई क्या है? (sin 25° = 0.4226)", options: ["84.50 mm", "84.52 mm", "84.51 mm", "85.20 mm"], answer: 1, image: "images/question28.png" },
    { qNum: 29, question: "How many set of feeler gauges are available as per BIS? बीआईएस के अनुसार फीलर गेज के कितने सेट उपलब्ध हैं?", options: ["Set No: 1,2", "Set No: 1,2,3,4", "Set No: 1,2,3,4,5", "Set No: 1,2,3,4,5,6"], answer: 1, image: "images/question29.png" },
    { qNum: 30, question: "What material is used to make radius and fillet gauge? रेडियस और फिलेट गेज बनाने के लिए कौन सी सामग्री उपयोग की जाती है?", options: ["Tool steel टूल स्टील", "Hardened steel sheet हार्डन्ड स्टील शीट", "High carbon steel हाई कार्बन स्टील", "Medium carbon steel मीडियम कार्बन स्टील"], answer: 1, image: "images/question30.png" },
    { qNum: 31, question: "What is the part marked as 'x' in lapping tool? लैपिंग टूल में चिह्नित 'x' भाग क्या है?", options: ["Slit स्लिट", "Bush बुश", "Sleeve स्लीव", "Groove ग्रूव"], answer: 0, image: "images/question31.png" },
    { qNum: 32, question: "What is the purpose of slit provided in the lapping tool? लैपिंग टूल में प्रदान की गई स्लिट का उद्देश्य क्या है?", options: ["For clearance क्लियरेंस के लिए", "For expansion विस्तार के लिए", "To retain abrasive अपघर्षक को बनाए रखने के लिए", "To adjust the sleeve स्लीव को समायोजित करने के लिए"], answer: 1, image: "images/question32.png" },
    { qNum: 33, question: "What is the name of operation? इस ऑपरेशन का नाम क्या है?", options: ["Internal ring lapping आंतरिक रिंग लैपिंग", "External ring lapping बाहरी रिंग लैपिंग", "Lapping internal cylinder आंतरिक सिलेंडर लैपिंग", "Lapping large diameter बड़े व्यास की लैपिंग"], answer: 3, image: "images/question33.png" },
    { qNum: 34, question: "What type of abrasives are used in honing cast iron and non-ferrous materials? कास्ट आयरन और गैर-लौह सामग्रियों के होनिंग में उपयोग किए जाने वाले अपघर्षक के प्रकार क्या हैं?", options: ["Diamond डायमंड", "Boron carbide बोरॉन कार्बाइड", "Silicon carbide सिलिकॉन कार्बाइड", "Aluminium oxide एल्यूमीनियम ऑक्साइड"], answer: 2, image: "images/question34.png" },
    { qNum: 35, question: "Which method of surface hardening, the surface remains free from scales? सतह कठोरन की कौन सी विधि में सतह स्केल से मुक्त रहती है?", options: ["Nitriding नाइट्राइडिंग", "Case hardening केस हार्डनिंग", "Flame hardening फ्लेम हार्डनिंग", "Induction hardening इंडक्शन हार्डनिंग"], answer: 3, image: "images/question35.png" },
    { qNum: 36, question: "What is the process if the steel is heated above critical temperature and soaking it for sufficient time and cooling it very slowly within furnace? यदि स्टील को क्रिटिकल तापमान से ऊपर गरम किया जाए और पर्याप्त समय तक भिगोकर भट्ठी में बहुत धीरे-धीरे ठंडा किया जाए, तो प्रक्रिया क्या है?", options: ["Annealing ऐनीलिंग", "Hardening हार्डनिंग", "Tempering टेंपरिंग", "Normalising नॉर्मलाइजिंग"], answer: 0, image: "images/question36.png" },
    { qNum: 37, question: "What is the process to refine the structure of steel component? स्टील घटक की संरचना को परिष्कृत करने की प्रक्रिया क्या है?", options: ["Tempering टेंपरिंग", "Annealing ऐनीलिंग", "Hardening हार्डनिंग", "Normalising नॉर्मलाइजिंग"], answer: 3, image: "images/question37.png" },
    { qNum: 38, question: "Which method of surface hardening is done in a heated salt bath? गरम नमक स्नान में सतह कठोरन की कौन सी विधि की जाती है?", options: ["Flame hardening फ्लेम हार्डनिंग", "Gas carburising गैस कार्बराइजिंग", "Pack carburising पैक कार्बराइजिंग", "Liquid carburising लिक्विड कार्बराइजिंग"], answer: 3, image: "images/question38.png" },
    { qNum: 39, question: "What is the name of part marked as 'X'? चिह्नित 'X' भाग का नाम क्या है?", options: ["Taper shaft टेपर शाफ्ट", "Splined shaft स्प्लाइंड शाफ्ट", "Serrated shaft सिरेटेड शाफ्ट", "Screw pitch gauge स्क्रू पिच गेज"], answer: 2, image: "images/question39.png" },
    { qNum: 40, question: "Which key has rectangular cross section is fit into keyway cut on both shaft and hub? आयताकार क्रॉस सेक्शन वाली कौन सी की शाफ्ट और हब दोनों पर कटे कीवे में फिट होती है?", options: ["Sunk key सनक की", "Feather key फेदर की", "Flat saddle key फ्लैट सैडल की", "Hollow saddle key हॉलो सैडल की"], answer: 0, image: "images/question40.png" },
    { qNum: 41, question: "Which key is useful for fitting on tapered shafts? टेपर्ड शाफ्ट्स पर फिटिंग के लिए कौन सी की उपयोगी है?", options: ["Feather key फेदर की", "Gib head key गिब हेड की", "Woodruff key वुडरफ की", "Flat saddle key फ्लैट सैडल की"], answer: 2, image: "images/question41.png" },
    { qNum: 42, question: "Where is circular taper key used? सर्कुलर टेपर की का उपयोग कहां किया जाता है?", options: ["Light duty transmission लाइट ड्यूटी ट्रांसमिशन", "Heavy duty transmission हैवी ड्यूटी ट्रांसमिशन", "Low speed required कम गति की आवश्यकता", "High speed required उच्च गति की आवश्यकता"], answer: 0, image: "images/question42.png" },
    { qNum: 43, question: "How the plain bearings are kept in a position without allowing them to rotate along with the shaft? शाफ्ट के साथ घूमने की अनुमति दिए बिना प्लेन बेयरिंग्स को कैसे पोजीशन में रखा जाता है?", options: ["By clamps क्लैम्प्स द्वारा", "By bolt and nut बोल्ट और नट द्वारा", "By key or screws की या स्क्रू द्वारा", "By locking device लॉकिंग डिवाइस द्वारा"], answer: 2, image: "images/question43.png" },
    { qNum: 44, question: "What is the name of key? इस की का नाम क्या है?", options: ["Flat saddle key फ्लैट सैडल की", "Taper sunk key टेपर सनक की", "Parallel sunk key पैरलल सनक की", "Hallow saddle key हॉलो सैडल की"], answer: 0, image: "images/question44.png" },
    { qNum: 45, question: "What is the name of key? इस की का नाम क्या है?", options: ["Sunk key सनक की", "Feather key फेदर की", "Gib head key गिब हेड की", "Wood ruff key वुडरफ की"], answer: 2, image: "images/question45.png" },
    { qNum: 46, question: "What is the file for lock repair and filing hard notches in keys? ताले की मरम्मत और कीज़ में कठोर नॉच्स की फाइलिंग के लिए कौन सी फाइल है?", options: ["Pillar file पिलर फाइल", "Flexible file फ्लेक्सिबल फाइल", "Warding file वार्डिंग फाइल", "Swiss pattern file स्विस पैटर्न फाइल"], answer: 2, image: "images/question46.png" },
    { qNum: 47, question: "What is the name of screw? इस स्क्रू का नाम क्या है?", options: ["Grub screw ग्रब स्क्रू", "Driver screw ड्राइवर स्क्रू", "Self taping screw सेल्फ टैपिंग स्क्रू", "Thread cutting screw थ्रेड कटिंग स्क्रू"], answer: 1, image: "images/question47.png" },
    { qNum: 48, question: "What is the advantage of lock washer? लॉक वॉशर का लाभ क्या है?", options: ["Provide increased bearing surface बढ़ी हुई बेयरिंग सतह प्रदान करना", "Prevent the damage to the surface सतह को नुकसान से रोकना", "Distribute even pressure on working surface कार्य सतह पर समान दबाव वितरित करना", "Prevent bolt or nut from loosening under vibration कंपन के तहत बोल्ट या नट को ढीला होने से रोकना"], answer: 3, image: "images/question48.png" },
    { qNum: 49, question: "What is the name of screw driver? इस स्क्रूड्राइवर का नाम क्या है?", options: ["Offset screw driver ऑफसेट स्क्रूड्राइवर", "Philips screw driver फिलिप्स स्क्रूड्राइवर", "Standard screw driver स्टैंडर्ड स्क्रूड्राइवर", "Heavy duty screw driver हैवी ड्यूटी स्क्रूड्राइवर"], answer: 0, image: "images/question49.png" },
    { qNum: 50, question: "What is the name of locking device? इस लॉकिंग डिवाइस का नाम क्या है?", options: ["Tab washer टैब वॉशर", "Locking plate लॉकिंग प्लेट", "Lock washer लॉक वॉशर", "Spring washer स्प्रिंग वॉशर"], answer: 3, image: "images/question50.png" }
];

console.log("Questions array loaded:", questions.length, "questions");

let timeLeft = 1500; // 25 minutes (1500 seconds) for 50 questions
let score = 0;

function displayQuestions() {
    console.log("Displaying questions...");
    const container = document.getElementById('question-container');
    if (!container) {
        console.error("Question container not found!");
        return;
    }
    questions.forEach((q) => {
        console.log(`Processing question ${q.qNum}`);
        let html = `
            <div class="question" id="question-${q.qNum}">
                <h3>Question ${q.qNum}: ${q.question}</h3>
                ${q.image ? `<img src="${q.image}" alt="Question ${q.qNum} diagram" style="max-width: 100%; height: auto; margin: 10px 0; display: none;" onload="this.style.display='block';">` : ''}
                <div class="options" id="options-${q.qNum}">`;
        
        q.options.forEach((option, i) => {
            html += `
                <label class="option-label">
                    <input type="radio" name="q${q.qNum}" value="${i}">
                    <span class="option-text" id="option-${q.qNum}-${i}">${option}</span>
                </label>`;
        });
        
        html += `
                </div>
                <div class="status" id="status-${q.qNum}"></div>
            </div>`;
        container.innerHTML += html;

        if (q.image) {
            const img = new Image();
            img.src = q.image;
            img.onload = () => {
                const imgElement = document.getElementById(`question-${q.qNum}`).querySelector('img');
                if (imgElement) {
                    imgElement.style.display = 'block';
                    console.log(`Image loaded for question ${q.qNum}: ${q.image}`);
                }
            };
            img.onerror = () => {
                // Do nothing if image doesn’t exist—no error, no display
                console.log(`Image not found for question ${q.qNum}: ${q.image}`);
            };
        }
    });
}

function startTimer() {
    console.log("Starting timer...");
    const timer = document.getElementById('timer');
    if (!timer) {
        console.error("Timer element not found!");
        return;
    }
    const interval = setInterval(() => {
        timeLeft--;
        timer.textContent = Math.floor(timeLeft / 60) + ':' + (timeLeft % 60).toString().padStart(2, '0');
        if (timeLeft <= 0) {
            clearInterval(interval);
            submitQuiz();
        }
    }, 1000);
}

function updateScore() {
    console.log("Updating score...");
    const scoreElement = document.getElementById('score');
    if (!scoreElement) {
        console.error("Score element not found!");
        return;
    }
    scoreElement.textContent = score;
}

function goBack() {
    console.log("Navigating back to homepage...");
    window.location.href = '../index.html';
}

function submitQuiz() {
    console.log("Submitting quiz...");
    let correct = 0;
    let wrong = 0;
    let notAttempted = 0;
    const total = questions.length;

    questions.forEach((q) => {
        console.log(`Processing submission for question ${q.qNum}`);
        const selected = document.querySelector(`input[name="q${q.qNum}"]:checked`)